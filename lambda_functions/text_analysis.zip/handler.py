"""
Simple Text Analysis Lambda Function
Analyzes text for emotion detection using basic NLP techniques
"""

import json
import logging
import os
import re
from datetime import datetime
from typing import Dict, List, Any
from collections import Counter

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler for text emotion analysis
    
    Trigger: API Gateway (text input)
    Purpose: Analyze text for emotions using basic NLP techniques
    """
    try:
        logger.info("=" * 50)
        logger.info("📝 TEXT ANALYSIS REQUEST STARTED")
        logger.info("=" * 50)
        logger.info(f"Request ID: {event.get('requestContext', {}).get('requestId')}")
        logger.info(f"Event keys: {list(event.keys())}")
        
        # Parse incoming text data robustly for API Gateway and direct Lambda invocation
        body = event.get('body', event)  # If 'body' is missing, assume direct Lambda invoke
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except Exception as e:
                logger.error(f"Failed to parse body string as JSON: {e}")
                body = {}
        elif not isinstance(body, dict):
            body = {}
        logger.info(f"Body keys: {list(body.keys())}")
        
        # Handle both text_data and text parameters
        text_data = body.get('text_data', '') or body.get('text', '')
        user_id = body.get('user_id', 'anonymous')
        session_id = body.get('session_id', 'default')
        
        logger.info(f"User ID: {user_id}")
        logger.info(f"Session ID: {session_id}")
        logger.info(f"Text data length: {len(text_data)} characters")
        logger.info(f"Text preview: {text_data[:100]}...")
        
        if not text_data:
            logger.error("❌ No text data provided")
            return create_error_response(400, "No text data provided")
        
        # Analyze emotions using basic NLP techniques
        logger.info("🔍 Starting text emotion analysis...")
        emotion_results = analyze_text_emotions(text_data)
        
        logger.info(f"📊 Analysis results: {len(emotion_results.get('emotions', []))} emotions detected")
        
        # Prepare response
        response_data = {
            'emotions': emotion_results.get('emotions', []),
            'primary_emotion': emotion_results.get('primary_emotion', 'neutral'),
            'confidence': emotion_results.get('confidence', 0.8),
            'sentiment': emotion_results.get('sentiment', 'neutral'),
            'keywords': emotion_results.get('keywords', []),
            'timestamp': datetime.utcnow().isoformat(),
            'processing_time_ms': context.get_remaining_time_in_millis() if context else 0,
            'debug_info': {
                'analysis_method': 'basic_nlp',
                'text_length': len(text_data),
                'environment': os.environ.get('STAGE', 'unknown')
            }
        }
        
        logger.info(f"✅ SUCCESS: Processed text emotions")
        logger.info(f"📊 Response: {response_data}")
        logger.info("=" * 50)
        return create_success_response(response_data)
        
    except Exception as e:
        logger.error(f"❌ ERROR in text analysis: {str(e)}")
        logger.error(f"Exception type: {type(e).__name__}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return create_error_response(500, f"Internal server error: {str(e)}")

def analyze_text_emotions(text_data: str) -> Dict[str, Any]:
    """
    Analyze text for emotions using basic NLP techniques
    """
    try:
        logger.info("🔍 ANALYZE_TEXT_EMOTIONS STARTED")
        logger.info(f"Text length: {len(text_data)}")
        
        # Extract text features
        text_features = extract_text_features(text_data)
        
        # Analyze sentiment
        sentiment = analyze_sentiment(text_data)
        
        # Extract keywords
        keywords = extract_keywords(text_data)
        
        # Predict emotions based on text features and sentiment
        emotions = predict_text_emotions(text_features, sentiment, keywords)
        
        logger.info(f"📝 TEXT ANALYSIS COMPLETED")
        logger.info(f"📊 Sentiment: {sentiment}")
        logger.info(f"🔑 Keywords: {keywords[:5]}")  # Show first 5 keywords
        logger.info(f"😊 Emotions: {[e['Type'] for e in emotions]}")
        
        return {
            'emotions': emotions,
            'sentiment': sentiment,
            'keywords': keywords,
            'primary_emotion': emotions[0]['Type'] if emotions else 'neutral',
            'confidence': emotions[0]['Confidence'] if emotions else 0.8
        }
        
    except Exception as e:
        logger.error(f"❌ Text analysis failed: {str(e)}")
        logger.info("🔄 Falling back to mock text detection")
        return mock_text_detection()

def extract_text_features(text_data: str) -> Dict[str, Any]:
    """
    Extract text features for emotion analysis
    """
    try:
        # Basic text preprocessing
        text_lower = text_data.lower()
        words = re.findall(r'\b\w+\b', text_lower)
        
        # Calculate basic features
        word_count = len(words)
        char_count = len(text_data)
        avg_word_length = char_count / word_count if word_count > 0 else 0
        
        # Count punctuation
        exclamation_count = text_data.count('!')
        question_count = text_data.count('?')
        period_count = text_data.count('.')
        
        # Count capitalization
        upper_case_count = sum(1 for c in text_data if c.isupper())
        upper_case_ratio = upper_case_count / char_count if char_count > 0 else 0
        
        return {
            'word_count': word_count,
            'char_count': char_count,
            'avg_word_length': avg_word_length,
            'exclamation_count': exclamation_count,
            'question_count': question_count,
            'period_count': period_count,
            'upper_case_ratio': upper_case_ratio,
            'words': words
        }
        
    except Exception as e:
        logger.error(f"❌ Feature extraction failed: {str(e)}")
        return {
            'word_count': 0,
            'char_count': len(text_data),
            'avg_word_length': 0,
            'exclamation_count': 0,
            'question_count': 0,
            'period_count': 0,
            'upper_case_ratio': 0,
            'words': []
        }

def analyze_sentiment(text_data: str) -> str:
    """
    Basic sentiment analysis using keyword matching
    """
    try:
        text_lower = text_data.lower()
        words = re.findall(r'\b\w+\b', text_lower)
        
        # Define sentiment keywords
        positive_words = {
            'good', 'great', 'awesome', 'excellent', 'amazing', 'wonderful', 'fantastic',
            'love', 'like', 'happy', 'joy', 'excited', 'pleased', 'satisfied', 'content',
            'beautiful', 'perfect', 'best', 'outstanding', 'brilliant', 'superb'
        }
        
        negative_words = {
            'bad', 'awful', 'terrible', 'horrible', 'hate', 'dislike', 'sad', 'angry',
            'frustrated', 'annoyed', 'disappointed', 'upset', 'worried', 'scared',
            'fear', 'anxious', 'nervous', 'stress', 'pain', 'suffering'
        }
        
        # Count positive and negative words
        positive_count = sum(1 for word in words if word in positive_words)
        negative_count = sum(1 for word in words if word in negative_words)
        
        # Determine sentiment
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'
            
    except Exception as e:
        logger.error(f"❌ Sentiment analysis failed: {str(e)}")
        return 'neutral'

def extract_keywords(text_data: str) -> List[str]:
    """
    Extract keywords from text
    """
    try:
        text_lower = text_data.lower()
        words = re.findall(r'\b\w+\b', text_lower)
        
        # Filter out common stop words
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
            'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those',
            'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them'
        }
        
        # Filter words and count frequency
        filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
        word_freq = Counter(filtered_words)
        
        # Return top keywords
        return [word for word, freq in word_freq.most_common(10)]
        
    except Exception as e:
        logger.error(f"❌ Keyword extraction failed: {str(e)}")
        return []

def predict_text_emotions(text_features: Dict[str, Any], sentiment: str, keywords: List[str]) -> List[Dict[str, Any]]:
    """
    Predict emotions based on text features and sentiment
    """
    try:
        emotions = []
        
        # Emotion keywords mapping
        emotion_keywords = {
            'happy': ['happy', 'joy', 'excited', 'great', 'awesome', 'love', 'wonderful', 'amazing', 'fantastic'],
            'sad': ['sad', 'unhappy', 'depressed', 'down', 'miserable', 'awful', 'terrible', 'bad'],
            'angry': ['angry', 'mad', 'furious', 'annoyed', 'frustrated', 'hate', 'irritated'],
            'surprised': ['surprised', 'shocked', 'amazed', 'wow', 'incredible', 'unbelievable'],
            'fear': ['scared', 'afraid', 'frightened', 'worried', 'anxious', 'nervous'],
            'calm': ['calm', 'peaceful', 'relaxed', 'serene', 'quiet', 'tranquil'],
        }
        
        words = text_features.get('words', [])
        word_count = text_features.get('word_count', 0)
        
        # Check for emotion keywords
        for emotion, keywords_list in emotion_keywords.items():
            matches = sum(1 for word in words if word in keywords_list)
            if matches > 0:
                confidence = min(matches / max(word_count, 1) * 10, 1.0)
                emotions.append({
                    'Type': emotion,
                    'Confidence': confidence
                })
        
        # Add sentiment-based emotions
        if sentiment == 'positive' and not any(e['Type'] == 'happy' for e in emotions):
            emotions.append({
                'Type': 'happy',
                'Confidence': 0.7
            })
        elif sentiment == 'negative' and not any(e['Type'] in ['sad', 'angry'] for e in emotions):
            emotions.append({
                'Type': 'sad',
                'Confidence': 0.6
            })
        
        # If no emotions detected, return neutral
        if not emotions:
            emotions.append({
                'Type': 'neutral',
                'Confidence': 0.8
            })
        
        # Sort by confidence
        emotions.sort(key=lambda x: x['Confidence'], reverse=True)
        
        return emotions
        
    except Exception as e:
        logger.error(f"❌ Emotion prediction failed: {str(e)}")
        return [{'Type': 'neutral', 'Confidence': 0.8}]

def mock_text_detection() -> Dict[str, Any]:
    """
    Mock text detection for fallback
    """
    return {
        'emotions': [{'Type': 'neutral', 'Confidence': 0.8}],
        'sentiment': 'neutral',
        'keywords': ['text', 'analysis'],
        'primary_emotion': 'neutral',
        'confidence': 0.8
    }

def create_success_response(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create a successful API Gateway response
    """
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
        },
        'body': json.dumps(data)
    }

def create_error_response(status_code: int, message: str) -> Dict[str, Any]:
    """
    Create an error API Gateway response
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
        },
        'body': json.dumps({'message': message})
    } 